% sim('vhdl_approximate_tanh_design',vhdl_approximate_tanh_tb);
 xmin = -5;
 xmax = +5;
 x= fi(-5:0.8:5,1,8);
%  y_out = 1-(2./(power(2,((4-1-(1/4)+(1/8))*x))+1));