% C:\Program Files\Polyspace\R2020a\toolbox\hdlcoder\hdlcoderdemos\matlabhdlcoderdemos
% https://www.mathworks.com/company/newsletters/articles/best-practices-for-converting-matlab-code-to-fixed-point.html
% https://www.mathworks.com/help/fixedpoint/ug/functions-supported-for-code-acceleration-and-code-generation-from-matlab.html
function vhdl_approximate_tanh_tb
  % Test inputs
  x_8  = fi(-5:0.08:5,1,8);
  x_16 = fi(-5:0.08:5,1,16);
  x_32 = fi(-5:0.08:5,1,32);
  % Run
 y = tanh( double(x_8) );
 y_power2_8 = vhdl_approximate_tanh_design( double( x_8));   % 8 bits
 %y_power2_16 = vhdl_approximate_tanh_design( double( x_16));   % 16 bits
 %y_power2_32 = vhdl_approximate_tanh_design( double( x_32));   % 32 bits

  figure;
  plot(x_8,y_power2_8,'r.',x_8,y,'b'),legend('power 2-8','power 2-16', 'power 2-32', 'tanh(x)');
  
%   plot(x_8,y_power2_8,'r.',x_16,y_power2_16,'r--', x_32,y_power2_32,'g.' ,x_8,y,'b'),legend('power 2-8','power 2-16', 'power 2-32', 'tanh(x)');
  title("tanh(x)& power 2 - 8 - 16 - 32 bits aproximation " );
  xlabel('x');
  ylabel('tanh(x)');
  
  
  error8_ = RMSE(y_power2_8,y);
  formatSpec = '%.10f';
  error8_=num2str(error8_,formatSpec);
  disp("error 8 bits:" + error8_);
 
  figure;
  err = abs(y - double(y_power2_8));
  plot(x_8, err);
  xlabel('theta');
  ylabel('error');
  title("tanh(x)& power 2 - 8 bits aproximation Error = " + error8_);
  grid on;
  
%   y_16 = tanh( double(x_16) );
%   error16_ = RMSE(y_power2_16,y_16);
%   formatSpec = '%.10f';
%   error16_=num2str(error16_,formatSpec);
%   disp("error 16 bits:" + error16_);
%   
%   figure;
%   err = abs(y_16 - double(y_power2_16));
%   plot(x_16, err);
%   xlabel('theta');
%   ylabel('error');
%   title("tanh(x)& power 2 - 16 bits aproximation Error = " + error16_);
%   grid on;
%   
%   y_32 = tanh( double(x_32) );
%   error32_ = RMSE(y_power2_32,y_32);
%   formatSpec = '%.10f';
%   error32_=num2str(error32_,formatSpec);
%   disp("error 32 bits:" + error32_);
%   
%   figure;
%   err_32 = abs(y_32 - double(y_power2_32));
%   plot(x_32, err_32);
%   xlabel('theta');
%   ylabel('error');
%   title("tanh(x)& power 2 - 32 bits aproximation Error = " + error32_);
%   grid on;

end
 

