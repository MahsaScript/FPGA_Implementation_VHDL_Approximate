SLStudio.Utils.RemoveHighlighting(get_param('sim_power2', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_sim_power2', 'handle'));
annotate_port('gm_sim_power2/vhdl_approximate_tanh_design_fixpt_slcfg', 0, 1, '');
annotate_port('gm_sim_power2/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 0, 1, '');
annotate_port('gm_sim_power2/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
annotate_port('gm_sim_power2/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
annotate_port('sim_power2/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
