function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/vhdl_approximate_tanh_design_fixpt_slcfg */
	this.urlHashMap["untitled:1"] = "untitled.vhd:54,55,56,57";
	/* <Root>/out1 */
	this.urlHashMap["untitled:3"] = "msg=rtwMsg_notTraceable&block=untitled:3";
	/* <S1>:1 */
	this.urlHashMap["untitled:1:1"] = "vhdl_approximate_tanh_design_fixpt_slcfg.vhd:74";
	/* <S1>:1:10 */
	this.urlHashMap["untitled:1:1:10"] = "msg=rtwMsg_optimizedSfObject&block=untitled:1:1:10";
	/* <S1>:1:51 */
	this.urlHashMap["untitled:1:1:51"] = "msg=rtwMsg_optimizedSfObject&block=untitled:1:1:51";
	/* <S1>:1:40 */
	this.urlHashMap["untitled:1:1:40"] = "vhdl_approximate_tanh_design_fixpt_slcfg.vhd:81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "untitled"};
	this.sidHashMap["untitled"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/in1"] = {sid: "untitled:2"};
	this.sidHashMap["untitled:2"] = {rtwname: "<Root>/in1"};
	this.rtwnameHashMap["<Root>/vhdl_approximate_tanh_design_fixpt_slcfg"] = {sid: "untitled:1"};
	this.sidHashMap["untitled:1"] = {rtwname: "<Root>/vhdl_approximate_tanh_design_fixpt_slcfg"};
	this.rtwnameHashMap["<Root>/out1"] = {sid: "untitled:3"};
	this.sidHashMap["untitled:3"] = {rtwname: "<Root>/out1"};
	this.rtwnameHashMap["<S1>:1"] = {sid: "untitled:1:1"};
	this.sidHashMap["untitled:1:1"] = {rtwname: "<S1>:1"};
	this.rtwnameHashMap["<S1>:1:10"] = {sid: "untitled:1:1:10"};
	this.sidHashMap["untitled:1:1:10"] = {rtwname: "<S1>:1:10"};
	this.rtwnameHashMap["<S1>:1:51"] = {sid: "untitled:1:1:51"};
	this.sidHashMap["untitled:1:1:51"] = {rtwname: "<S1>:1:51"};
	this.rtwnameHashMap["<S1>:1:40"] = {sid: "untitled:1:1:40"};
	this.sidHashMap["untitled:1:1:40"] = {rtwname: "<S1>:1:40"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
