SLStudio.Utils.RemoveHighlighting(get_param('Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9', 'handle'));
annotate_port('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9/Source', 1, 1, '');
annotate_port('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9/Source/SigSpec1', 0, 1, '');
annotate_port('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9/Source/DTC1', 0, 1, '');
annotate_port('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9/Source/LUT', 0, 1, '');
annotate_port('gm_Approximate_id_0af2ac3f3b928182f3ff557fc379a1d7491938e9/Source/PipelineRegister', 1, 1, '');
