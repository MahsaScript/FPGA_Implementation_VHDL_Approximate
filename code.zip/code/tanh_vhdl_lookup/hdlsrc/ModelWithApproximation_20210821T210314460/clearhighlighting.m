SLStudio.Utils.RemoveHighlighting(get_param('ModelWithApproximation_20210821T210314460', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_ModelWithApproximation_20210821T210314460', 'handle'));
annotate_port('gm_ModelWithApproximation_20210821T210314460/Input1', 0, 1, '');
annotate_port('gm_ModelWithApproximation_20210821T210314460/Input1/LimitedCounter', 0, 1, '');
