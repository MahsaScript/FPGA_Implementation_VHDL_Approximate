SLStudio.Utils.RemoveHighlighting(get_param('untitled', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_untitled', 'handle'));
annotate_port('gm_untitled/vhdl_approximate_tanh_design_fixpt_slcfg', 0, 1, '');
annotate_port('gm_untitled/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 0, 1, '');
annotate_port('gm_untitled/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
annotate_port('gm_untitled/vhdl_approximate_tanh_design_fixpt_slcfg/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
annotate_port('untitled/vhdl_approximate_tanh_design_fixpt_slcfg', 1, 1, '');
